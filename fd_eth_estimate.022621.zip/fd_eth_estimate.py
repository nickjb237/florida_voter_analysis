# -*- coding: utf-8 -*-
"""
FloDems: Subethnicity Model

The object of this program is to take any name and calculate the probability
that the person belongs to a certain Hispanic ethnic group.

Based on findings provided by Florida Democrats on how common each name, first
and last is, in each Hispanic ethnic group.

The model prioritizes last name correlation over first name correlation
(70/30 ratio) by using a weighted average between the two, and calculates
the probability that the name is of each Hispanic origin, and then prioritizes
one ethnicity overall as the predicted ethnicity.

Created by: Nick Bauman
Advised by: Dr. Mihhail Berezovski
"""
import pandas as pd

def retrieve_name_proportions( in_lastname ):
    """
    fd_retrieve_name_proportions

    Consults the lastnames.csv database and returns how common a last name is
    in each Hispanic ethnic group.
    """

  # The file lastnames.csv is the model that represent
  # how popular each first and last name are in each Hispanic ethnic group.

    lastnames = pd.read_csv( "lastnames.csv", 
                        dtype = { "Mexican" : str, "%" : float, "PuertoRican" : str, 
                                 "%.1" : float, "Cuban" : str, "%.2" : float, 
                                 "Dominican" : str, "%.3" : float, "CostaRican" : str, 
                                 "%.4" : float, "Guatemalan" : str, "%.5" : float, 
                                 " Honduran" : str, "%.6" : float, "Nicaraguan" : str, 
                                 "%.7" : float, "Panamanian" : str, "%.8" : float, 
                                 "Salvadoran" : str, "%.9" : float, " Argentinean" : str, 
                                 "%.10" : float, "Bolivian" : str, "%.11" : float, 
                                 "Chilean" : str, "%.12" : float, "Colombian" : str, 
                                 "%.13" : float, "Ecuadorian" : str, "%.14" : float, 
                                 "Paraguayan" : str, "%.15" : float, "Peruvian" : str, 
                                 "%.16" : float, "Uruguayan" : str, "%.17" : float, 
                                 "Venezuelan" : str, "%.18" : float },
                        delimiter="," )
  # List of all these for iteration purposes.
    d_s_eth =   {   1:"s_mex", 2:"s_prc", 3:"s_cbn", 4:"s_dom", 5:"s_csr", 6:"s_gua",
                7:"s_hon", 8:"s_nic", 9:"s_pan", 10:"s_svd", 11:"s_arg", 12:"s_bol",
                13:"s_che", 14:"s_col", 15:"s_ecu", 16:"s_par", 17:"s_per", 
                18:"s_uru", 19:"s_vez" }
    d_l_eth =   {   1: "l_mex", 2:"l_prc", 3:"l_cbn", 4:"l_dom", 5:"l_csr", 6:"l_gua",
                7: "l_hon", 8:"l_nic", 9:"l_pan", 10:"l_svd", 11:"l_arg", 12:"l_bol",
                13:"l_che", 14:"l_col", 15:"l_ecu", 16:"l_par", 17:"l_per",
                18:"l_uru", 19:"l_vez" }
    eths = {    1:"Mexican", 2:"PuertoRican", 3:"Cuban", 4:"Dominican", 5:"Costa Rican",
            6:"Guatemalan", 7:"Honduran", 8:"Nicaraguan", 9:"Panamanian", 10:"Salvadoran",
            11:" Argentinean", 12:"Bolivian", 13:"Chilean", 14:"Colombian", 15:"Ecuadorian",
            16:"Paraguayan", 17:"Peruvian", 18:"Uruguayan", 19:"Venezuelan" }
    df_pct_cols = {    1:"%", 2:"%.1", 3:"%.2", 4:"%.3", 5:"%.4", 6:"%.5", 7:"%.6", 
                   8:"%.7", 9:"%.8", 10:"%.9", 11:"%.10", 12:"%.11", 13:"%.12", 
                   14:"%.13", 15:"%.14", 16:"%.15", 
                   17:"%.16", 18:"%.17", 19:"%.18" }

  # Iteration constant.
    num_eths = list( range( 1, 20 ))

    fd_name_proportions = {}

  # The loop separates each of the ethnicities into lists and series' that can be used
  # for further analysis.
    for i in num_eths:
        d_l_eth[ i ] = list( lastnames[ df_pct_cols[ i ]])
        d_s_eth[ i ] = pd.Series(   data = d_l_eth[ i ], 
                                index = lastnames[ eths[ i ]],
                                dtype = float )
      # Return proportion of given name for each ethnic group.
      # First, check to see if it exists in the group.
        if in_lastname in d_s_eth[ i ]:
            temp_prop = d_s_eth[ i ].loc[ in_lastname ]
            fd_name_proportions.update({ temp_prop : eths[ i ]})
        else:
            fd_name_proportions.update({ float(0) : eths[ i ]})
            # Set up the return variable; a pandas Series indexed by the ethnicities.
    fd_name_proportions = pd.Series( data=fd_name_proportions.keys(), index=fd_name_proportions.values())
    return fd_name_proportions

def retrieve_name_proportion_in_group( lastname, ethnic_group ):
    """
    An evolved version of retrieve_name_proportions, but the second argument
    specifies a particular Hispanic ethnic group.
    """
    t = retrieve_name_proportions( lastname )
    name_prop_in_group = t.loc[ ethnic_group ]
    return name_prop_in_group
        
def standardize( proportion, all_proportions ):
    """
    General function that standardizes any given ratio.
    Notably used to standardize the probability of a last name being of each
    ethnic group.

    all_proportions has to be a list of floats that contains a list of ratios.
    """
    sum_all = sum( all_proportions )
    standard_probability = proportion / sum_all
    return standard_probability

k = retrieve_name_proportions( "Suarez" )
i = retrieve_name_proportion_in_group( "Suarez", "Cuban" )

x = standardize( i, k )
    


        






